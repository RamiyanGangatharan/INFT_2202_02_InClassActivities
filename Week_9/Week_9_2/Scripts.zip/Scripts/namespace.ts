"use strict";

namespace core
{

}
